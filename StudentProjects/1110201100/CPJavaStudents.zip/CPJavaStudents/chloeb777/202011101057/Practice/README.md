# Practice
Practice programs for CPJava course

### 1.  Clone this repository for use in submitting Practice programs. 
![alt text][clonerep]
### 2.  Click the "Add File" button to add a distinct xxxx.pde files for each Practice code you develop in Processing. 
![alt text][addfile]
### 3.  Make sure what you have in Github is the latest version of your code for each practice xxxx.pde you created.
### 4.  Keep the versions updated even if your code is not working. This way I can help debug and offer suggestions.  

[addfile]: addfile.png "addfile"
[clonerep]: clonerep.png "clonerep"
